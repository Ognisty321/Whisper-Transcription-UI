#!/usr/bin/env python3
"""Build, selectively modernize, test, package, and host Faster-Whisper-XXL.

Every non-core dependency group is applied transactionally. A candidate is kept
only after bundled imports, numerical/audio/media checks, HTTPS/Hugging Face,
CLI smoke tests, the launcher's self-test, and an end-to-end tiny.en CPU
transcription all pass on Windows.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

ORIGINAL_URL = (
    "https://github.com/Purfview/whisper-standalone-win/releases/download/"
    "Faster-Whisper-XXL/Faster-Whisper-XXL_r245.4_windows.7z"
)
ORIGINAL_SIZE = 1_424_256_246
ORIGINAL_SHA256 = "237DEE23939CDABFC96EF859FC5E584B842C3A5557E0D2CA744E1F87C14C5844"
DEFAULT_ARCHIVE = "Faster-Whisper-XXL_r245.4_COMPREHENSIVE_RTX50_CUDA128.zip"
PYINSTALLER_VERSION = "6.22.2"

WORKSPACE = Path.cwd().resolve()
WORK = WORKSPACE / "comprehensive-work"
REPORT = WORKSPACE / "comprehensive-report"
TOOLS = WORKSPACE / "tools"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def json_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def status(message: str) -> None:
    line = f"[{utc_now()}] {message}"
    print(line, flush=True)
    REPORT.mkdir(parents=True, exist_ok=True)
    with (REPORT / "build-status.txt").open("a", encoding="utf-8") as stream:
        stream.write(line + "\n")


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", value).strip("-") or "step"


def command_text(command: Sequence[str | os.PathLike[str]]) -> str:
    return subprocess.list2cmdline([os.fspath(item) for item in command])


def run(
    command: Sequence[str | os.PathLike[str]],
    *,
    log: Path,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    check: bool = True,
    timeout: int | None = None,
) -> subprocess.CompletedProcess[str]:
    log.parent.mkdir(parents=True, exist_ok=True)
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    print(f"+ {command_text(command)}", flush=True)
    with log.open("w", encoding="utf-8", errors="replace") as stream:
        stream.write(f"COMMAND: {command_text(command)}\n")
        stream.write(f"CWD: {cwd or WORKSPACE}\n\n")
        stream.flush()
        process = subprocess.Popen(
            [os.fspath(item) for item in command],
            cwd=str(cwd) if cwd else None,
            env=merged_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        lines: list[str] = []
        started = time.monotonic()
        assert process.stdout is not None
        while True:
            line = process.stdout.readline()
            if line:
                print(line, end="", flush=True)
                stream.write(line)
                lines.append(line)
                if len(lines) > 300:
                    del lines[:100]
            elif process.poll() is not None:
                break
            elif timeout is not None and time.monotonic() - started > timeout:
                process.kill()
                process.wait()
                raise TimeoutError(f"Command timed out after {timeout}s: {command_text(command)}")
        return_code = process.wait()
        output = "".join(lines)
    result = subprocess.CompletedProcess(command, return_code, output, "")
    if check and return_code != 0:
        raise subprocess.CalledProcessError(return_code, command, output=output)
    return result


def run_capture(
    command: Sequence[str | os.PathLike[str]],
    *,
    log: Path,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    check: bool = True,
    timeout: int | None = None,
) -> str:
    result = run(command, log=log, cwd=cwd, env=env, check=check, timeout=timeout)
    return result.stdout or ""


def remove_path(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    elif path.exists() or path.is_symlink():
        path.unlink()


def copy_entry(source: Path, destination: Path) -> None:
    if destination.exists() or destination.is_symlink():
        remove_path(destination)
    if source.is_dir() and not source.is_symlink():
        shutil.copytree(source, destination)
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def download(url: str, output: Path, log_name: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    run(
        [
            "curl.exe", "--location", "--fail", "--retry", "5",
            "--retry-all-errors", "--retry-delay", "5", "--output", output, url,
        ],
        log=REPORT / log_name,
        timeout=1200,
    )


def pip_install_target(
    stage: Path,
    packages: Sequence[str],
    *,
    label: str,
    index_url: str | None = None,
    no_deps: bool = False,
) -> None:
    remove_path(stage)
    stage.mkdir(parents=True)
    command: list[str | os.PathLike[str]] = [
        sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
        "--no-input", "--no-cache-dir", "--only-binary=:all:", "--target", stage,
    ]
    if no_deps:
        command.append("--no-deps")
    if index_url:
        command.extend(["--index-url", index_url])
    command.extend(packages)
    run(command, log=REPORT / f"pip-{safe_name(label)}.txt", timeout=2400)


def overlay_apply(contents: Path, stage: Path, backup: Path, manifest: Path, label: str) -> None:
    run(
        [sys.executable, TOOLS / "overlay_python_stage.py", "apply", contents, stage, backup, "--manifest", manifest],
        log=REPORT / f"overlay-apply-{safe_name(label)}.txt",
    )


def overlay_rollback(contents: Path, backup: Path, label: str) -> None:
    run(
        [sys.executable, TOOLS / "overlay_python_stage.py", "rollback", contents, backup],
        log=REPORT / f"overlay-rollback-{safe_name(label)}.txt",
    )
    remove_path(backup)


def overlay_commit(backup: Path, label: str) -> None:
    run(
        [sys.executable, TOOLS / "overlay_python_stage.py", "commit", backup],
        log=REPORT / f"overlay-commit-{safe_name(label)}.txt",
    )


def build_launcher(python_exe: Path, bundle_root: Path, contents: Path, label: str) -> None:
    dist = WORK / f"launcher-dist-{safe_name(label)}"
    build = WORK / f"launcher-build-{safe_name(label)}"
    spec = WORK / f"launcher-spec-{safe_name(label)}"
    for path in (dist, build, spec):
        remove_path(path)
    run(
        [
            python_exe, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir", "--console",
            "--name", "faster-whisper-xxl", "--contents-directory", "_xxl_data",
            "--distpath", dist, "--workpath", build, "--specpath", spec,
            TOOLS / "xxl_launcher_comprehensive.py",
        ],
        log=REPORT / f"pyinstaller-build-{safe_name(label)}.txt",
        timeout=1200,
    )
    launcher = dist / "faster-whisper-xxl"
    copy_entry(launcher / "faster-whisper-xxl.exe", bundle_root / "faster-whisper-xxl.exe")
    for item in (launcher / "_xxl_data").iterdir():
        copy_entry(item, contents / item.name)


def exe_environment(contents: Path) -> dict[str, str]:
    return {
        "HF_HUB_DISABLE_XET": "1",
        "HF_HUB_ENABLE_HF_TRANSFER": "0",
        "TOKENIZERS_PARALLELISM": "false",
        "PYTHONNOUSERSITE": "1",
        "PATH": os.pathsep.join(
            [
                str(contents / "torch" / "lib"),
                str(contents / "ctranslate2"),
                str(contents / "onnxruntime" / "capi"),
                str(contents),
                os.environ.get("PATH", ""),
            ]
        ),
    }


class Builder:
    def __init__(self, archive_name: str, git_sha: str) -> None:
        self.archive_name = archive_name
        self.git_sha = git_sha
        self.bundle_root: Path
        self.contents: Path
        self.exe: Path
        self.model_dir = WORK / "models"
        self.test_wav = REPORT / "decoder-test.wav"
        self.decisions: list[dict[str, Any]] = []
        self.accepted_versions: dict[str, str] = {}
        self.patch_report: dict[str, Any] = {}
        self.final_validation: dict[str, Any] = {}
        self.python_runtime_decision: dict[str, Any] | None = None
        self.ffmpeg_decision: dict[str, Any] | None = None

    def record(self, *, name: str, status_value: str, category: str, details: Any) -> None:
        entry = {
            "name": name,
            "category": category,
            "status": status_value,
            "tested_at_utc": utc_now(),
            "details": details,
        }
        self.decisions.append(entry)
        json_write(REPORT / "dependency-decisions.json", self.decisions)

    def prepare(self) -> None:
        status("Downloading and verifying the original r245.4 archive.")
        remove_path(WORK)
        remove_path(REPORT)
        WORK.mkdir(parents=True)
        REPORT.mkdir(parents=True)
        original = WORK / "original.7z"
        download(ORIGINAL_URL, original, "download-original.txt")
        size = original.stat().st_size
        digest = sha256_file(original)
        json_write(REPORT / "original-archive.json", {"url": ORIGINAL_URL, "size_bytes": size, "sha256": digest})
        if size != ORIGINAL_SIZE or digest != ORIGINAL_SHA256:
            raise RuntimeError(f"Original archive verification failed: size={size}, sha256={digest}")
        extracted = WORK / "extracted"
        run(["7z.exe", "x", original, f"-o{extracted}", "-y"], log=REPORT / "7z-extract.txt", timeout=1200)
        original.unlink()
        self.bundle_root = extracted / "Faster-Whisper-XXL"
        self.contents = self.bundle_root / "_xxl_data"
        self.exe = self.bundle_root / "faster-whisper-xxl.exe"
        if not self.contents.is_dir() or not self.exe.is_file():
            raise FileNotFoundError("Extracted application structure is incomplete")
        (REPORT / "bundle-root.txt").write_text(str(self.bundle_root) + "\n", encoding="utf-8")

        status("Installing the current PyInstaller and externalizing all original CPython 3.10 bytecode.")
        run(
            [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", f"pyinstaller=={PYINSTALLER_VERSION}"],
            log=REPORT / "pip-pyinstaller.txt",
            timeout=600,
        )
        run(
            [
                sys.executable, TOOLS / "externalize_pyz.py", self.exe, self.contents,
                "--scripts-dir", self.contents / "xxl_original_scripts",
                "--manifest", self.contents / "xxl_externalization_manifest.json",
            ],
            log=REPORT / "externalize.txt",
            timeout=900,
        )
        shutil.copy2(self.contents / "xxl_externalization_manifest.json", REPORT / "xxl_externalization_manifest.json")

        status("Applying the validated --diarize + --postfix bytecode fix.")
        patch_file = self.contents / "xxl_original_scripts" / "__main__.marshal"
        patch_report_path = REPORT / "postfix-diarization-patch.json"
        run(
            [
                sys.executable, TOOLS / "patch_xxl_main.py", patch_file,
                "--report", patch_report_path,
                "--backup", REPORT / "__main__.marshal.before-postfix-fix",
            ],
            log=REPORT / "patch-postfix-diarization.txt",
        )
        self.patch_report = json.loads(patch_report_path.read_text(encoding="utf-8"))

    def install_gpu_core(self) -> None:
        status("Installing the coherent CUDA 12.8 / Blackwell GPU core.")
        stage = WORK / "stage-gpu-core"
        pip_install_target(
            stage,
            ["torch==2.11.0", "torchvision==0.26.0", "torchaudio==2.11.0"],
            label="gpu-pytorch",
            index_url="https://download.pytorch.org/whl/cu128",
            no_deps=True,
        )
        pip_install_target(
            WORK / "stage-gpu-native",
            ["ctranslate2==4.8.1", "onnxruntime-gpu==1.23.2"],
            label="gpu-native",
            no_deps=True,
        )
        # Merge both mandatory stages before the transactional overlay.
        native = WORK / "stage-gpu-native"
        for item in native.iterdir():
            destination = stage / item.name
            if destination.exists():
                remove_path(destination)
            copy_entry(item, destination)
        backup = WORK / "backup-gpu-core"
        manifest = REPORT / "overlay-gpu-core.json"
        overlay_apply(self.contents, stage, backup, manifest, "gpu-core")
        overlay_commit(backup, "gpu-core")
        remove_path(stage)
        remove_path(native)

        status("Rebuilding the launcher with PyInstaller 6.22.2 and hardened runtime diagnostics.")
        build_launcher(Path(sys.executable), self.bundle_root, self.contents, "base-comprehensive")
        self.exe = self.bundle_root / "faster-whisper-xxl.exe"

    def validate_python_stack(self, label: str, expectations: dict[str, str] | None = None) -> dict[str, Any]:
        output = REPORT / f"validation-{safe_name(label)}.json"
        command: list[str | os.PathLike[str]] = [
            sys.executable, TOOLS / "validate_xxl_stack_v2.py", self.contents,
            "--output", output, "--deep", "--network",
        ]
        for name, version in (expectations or {}).items():
            command.extend(["--expect", f"{name}={version}"])
        run(command, log=REPORT / f"validation-{safe_name(label)}.txt", timeout=900)
        report = json.loads(output.read_text(encoding="utf-8"))
        if report.get("failures"):
            raise RuntimeError(f"Validation failures for {label}: {report['failures']}")
        return report

    def exe_self_test(self, label: str) -> dict[str, Any]:
        output = run_capture(
            [self.exe, "--xxl-self-test"],
            log=REPORT / f"exe-self-test-{safe_name(label)}.txt",
            cwd=self.bundle_root,
            env=exe_environment(self.contents),
            timeout=600,
        )
        start = output.find("{")
        if start < 0:
            raise RuntimeError("Launcher self-test did not emit JSON")
        data = json.loads(output[start:])
        if any(not item.get("ok") for item in data.get("modules", [])):
            raise RuntimeError("Launcher self-test reported module import failures")
        if "sm_120" not in str(data.get("torch_arch_flags", "")).split():
            raise RuntimeError("Launcher self-test did not confirm sm_120")
        return data

    def cli_smoke(self, label: str) -> None:
        for argument in ("--help", "--version", "--checkcuda"):
            run(
                [self.exe, argument],
                log=REPORT / f"cli-{safe_name(label)}-{argument[2:]}.txt",
                cwd=self.bundle_root,
                env=exe_environment(self.contents),
                timeout=300,
            )

    def inference(self, label: str, *, fresh_model: bool = False) -> dict[str, Any]:
        if not self.test_wav.is_file():
            run([sys.executable, TOOLS / "generate_test_wav.py", self.test_wav], log=REPORT / "generate-test-wav.txt")
        model_dir = WORK / (f"models-{safe_name(label)}" if fresh_model else "models")
        if fresh_model:
            remove_path(model_dir)
        model_dir.mkdir(parents=True, exist_ok=True)
        output_dir = REPORT / "inference" / safe_name(label)
        remove_path(output_dir)
        output_dir.mkdir(parents=True)
        run(
            [
                self.exe, self.test_wav, "--model", "tiny.en", "--model_dir", model_dir,
                "--device", "cpu", "--compute_type", "int8", "--language", "en",
                "--output_dir", output_dir, "--output_format", "txt", "--verbose", "false",
                "--beep_off",
            ],
            log=REPORT / f"inference-{safe_name(label)}.txt",
            cwd=self.bundle_root,
            env=exe_environment(self.contents),
            timeout=1200,
        )
        outputs = [path for path in output_dir.rglob("*.txt") if path.stat().st_size > 0]
        if not outputs:
            raise RuntimeError(f"Inference {label} did not create a non-empty text output")
        return {"output_files": [str(path.relative_to(REPORT)) for path in outputs], "model_dir": str(model_dir)}

    def full_validation(self, label: str, expectations: dict[str, str] | None = None, *, fresh_model: bool = False) -> dict[str, Any]:
        python_report = self.validate_python_stack(label, expectations)
        runtime_report = self.exe_self_test(label)
        self.cli_smoke(label)
        inference_report = self.inference(label, fresh_model=fresh_model)
        return {
            "python_validation": str((REPORT / f"validation-{safe_name(label)}.json").name),
            "runtime": runtime_report,
            "inference": inference_report,
            "versions": python_report.get("versions", {}),
        }

    def try_group(
        self,
        name: str,
        packages: Sequence[str],
        *,
        category: str,
        expectations: dict[str, str],
        no_deps: bool = False,
    ) -> bool:
        status(f"Testing transactional dependency group: {name}.")
        stage = WORK / f"stage-{safe_name(name)}"
        backup = WORK / f"backup-{safe_name(name)}"
        manifest = REPORT / f"overlay-{safe_name(name)}.json"
        try:
            pip_install_target(stage, packages, label=name, no_deps=no_deps)
            overlay_apply(self.contents, stage, backup, manifest, name)
            validation = self.full_validation(name, expectations)
            overlay_commit(backup, name)
            self.accepted_versions.update(validation.get("versions", {}))
            self.record(
                name=name,
                status_value="accepted",
                category=category,
                details={"requested_packages": list(packages), "expectations": expectations, "validation": validation},
            )
            return True
        except BaseException as exc:
            error = {"error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(limit=30)}
            if backup.exists():
                with contextlib.suppress(Exception):
                    overlay_rollback(self.contents, backup, name)
            self.record(
                name=name,
                status_value="rejected-and-rolled-back",
                category=category,
                details={"requested_packages": list(packages), "expectations": expectations, **error},
            )
            # The rollback itself must leave a fully operational application.
            self.full_validation(f"rollback-{name}")
            return False
        finally:
            remove_path(stage)
            remove_path(backup)

    def test_official_faster_whisper(self) -> None:
        name = "official-faster-whisper-1.2.1"
        status("Testing, without applying, whether upstream faster-whisper can replace the custom XXL fork.")
        stage = WORK / "stage-official-faster-whisper"
        try:
            pip_install_target(stage, ["faster-whisper==1.2.1"], label=name, no_deps=True)
            script = r'''
import importlib, json, sys
stage, bundle = sys.argv[1:3]
sys.path[:0] = [stage, bundle]
result = {}
try:
    fw = importlib.import_module("faster_whisper")
    utils = importlib.import_module("faster_whisper.utils")
    result["version"] = getattr(fw, "__version__", None)
    result["custom_diarization"] = importlib.util.find_spec("faster_whisper.diarization") is not None
    result["download_model_other"] = hasattr(utils, "download_model_other")
    transcribe = importlib.import_module("faster_whisper.transcribe")
    result["batched"] = hasattr(transcribe, "BatchedInferencePipeline")
except Exception as exc:
    result["error"] = f"{type(exc).__name__}: {exc}"
print(json.dumps(result))
'''
            output = run_capture(
                [sys.executable, "-c", script, stage, self.contents],
                log=REPORT / "official-faster-whisper-api-test.txt",
                timeout=120,
                check=False,
            )
            data = json.loads(output.strip().splitlines()[-1])
            compatible = bool(data.get("custom_diarization") and data.get("download_model_other") and data.get("batched"))
            self.record(
                name=name,
                status_value="not-applied-compatible" if compatible else "rejected-custom-xxl-api-loss",
                category="custom-application-core",
                details=data,
            )
        except BaseException as exc:
            self.record(
                name=name,
                status_value="rejected-test-failed",
                category="custom-application-core",
                details={"error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(limit=20)},
            )
        finally:
            remove_path(stage)

    def try_ffmpeg(self) -> bool:
        name = "ffmpeg-current-stable-windows-x64"
        status("Testing the current stable Windows x64 FFmpeg/FFprobe build transactionally.")
        backup_dir = WORK / "backup-ffmpeg"
        remove_path(backup_dir)
        backup_dir.mkdir(parents=True)
        try:
            request = urllib.request.Request(
                "https://api.github.com/repos/BtbN/FFmpeg-Builds/releases/latest",
                headers={"User-Agent": "xxl-comprehensive-builder/1"},
            )
            with urllib.request.urlopen(request, timeout=30) as response:
                release = json.load(response)
            candidates: list[tuple[tuple[int, ...], dict[str, Any]]] = []
            pattern = re.compile(r"^ffmpeg-n(\d+(?:\.\d+)*)-latest-win64-gpl-(\d+(?:\.\d+)*)\.zip$", re.I)
            for asset in release.get("assets", []):
                match = pattern.match(str(asset.get("name", "")))
                if not match:
                    continue
                version = tuple(int(item) for item in match.group(1).split("."))
                candidates.append((version, asset))
            if not candidates:
                raise RuntimeError("No stable static Windows x64 GPL FFmpeg asset found")
            _, asset = max(candidates, key=lambda item: item[0])
            archive = WORK / asset["name"]
            download(asset["browser_download_url"], archive, "download-ffmpeg.txt")
            digest = sha256_file(archive)
            expected_digest = str(asset.get("digest") or "")
            if expected_digest.startswith("sha256:") and digest.lower() != expected_digest.split(":", 1)[1].lower():
                raise RuntimeError("FFmpeg release asset SHA256 mismatch")
            extracted = WORK / "ffmpeg-extracted"
            remove_path(extracted)
            run(["7z.exe", "x", archive, f"-o{extracted}", "-y"], log=REPORT / "extract-ffmpeg.txt")
            ffmpeg = next(extracted.rglob("ffmpeg.exe"))
            ffprobe = next(extracted.rglob("ffprobe.exe"))
            for current in (self.bundle_root / "ffmpeg.exe", self.bundle_root / "ffprobe.exe"):
                if current.exists():
                    shutil.copy2(current, backup_dir / current.name)
            shutil.copy2(ffmpeg, self.bundle_root / "ffmpeg.exe")
            shutil.copy2(ffprobe, self.bundle_root / "ffprobe.exe")

            version_output = run_capture([self.bundle_root / "ffmpeg.exe", "-version"], log=REPORT / "ffmpeg-version-new.txt")
            probe_output = run_capture([self.bundle_root / "ffprobe.exe", "-version"], log=REPORT / "ffprobe-version-new.txt")
            if not self.test_wav.is_file():
                run([sys.executable, TOOLS / "generate_test_wav.py", self.test_wav], log=REPORT / "generate-test-wav.txt")
            flac = REPORT / "ffmpeg-roundtrip.flac"
            run([self.bundle_root / "ffmpeg.exe", "-y", "-i", self.test_wav, flac], log=REPORT / "ffmpeg-transcode.txt")
            run([self.bundle_root / "ffprobe.exe", "-v", "error", "-show_streams", "-of", "json", flac], log=REPORT / "ffprobe-media.txt")
            validation = self.full_validation(name)
            self.ffmpeg_decision = {
                "asset": asset["name"],
                "asset_url": asset["browser_download_url"],
                "asset_sha256": digest,
                "ffmpeg_first_line": version_output.splitlines()[0] if version_output else "",
                "ffprobe_first_line": probe_output.splitlines()[0] if probe_output else "",
                "validation": validation,
            }
            self.record(name=name, status_value="accepted", category="external-media-tools", details=self.ffmpeg_decision)
            return True
        except BaseException as exc:
            for filename in ("ffmpeg.exe", "ffprobe.exe"):
                current = self.bundle_root / filename
                backup = backup_dir / filename
                if backup.exists():
                    shutil.copy2(backup, current)
                elif current.exists() and filename == "ffprobe.exe":
                    current.unlink()
            self.record(
                name=name,
                status_value="rejected-and-rolled-back",
                category="external-media-tools",
                details={"error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(limit=30)},
            )
            self.full_validation("rollback-ffmpeg")
            return False
        finally:
            remove_path(backup_dir)
            for path in (WORK / "ffmpeg-extracted",):
                remove_path(path)

    def try_cpython_31021(self) -> bool:
        name = "cpython-3.10.21-security-runtime"
        status("Building and transactionally testing CPython 3.10.21 from the official source tag.")
        source = WORK / "cpython-3.10.21"
        stage = WORK / "stage-python31021"
        backup = WORK / "backup-python31021"
        manifest = REPORT / "overlay-python31021.json"
        exe_backup = WORK / "faster-whisper-xxl.before-python31021.exe"
        try:
            remove_path(source)
            run(
                ["git.exe", "clone", "--depth", "1", "--branch", "v3.10.21", "https://github.com/python/cpython.git", source],
                log=REPORT / "clone-cpython31021.txt",
                timeout=900,
            )
            run(
                ["cmd.exe", "/d", "/s", "/c", "PCbuild\\build.bat -p x64 -c Release"],
                log=REPORT / "build-cpython31021.txt",
                cwd=source,
                timeout=3600,
            )
            python_exe = source / "PCbuild" / "amd64" / "python.exe"
            runtime_info = run_capture(
                [python_exe, "-c", "import json,ssl,sqlite3,sys,zlib;print(json.dumps({'python':sys.version,'openssl':ssl.OPENSSL_VERSION,'sqlite':sqlite3.sqlite_version,'zlib':zlib.ZLIB_VERSION}))"],
                log=REPORT / "cpython31021-runtime.txt",
            )
            run([python_exe, "-m", "ensurepip", "--upgrade"], log=REPORT / "cpython31021-ensurepip.txt", cwd=source, timeout=900)
            run(
                [python_exe, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", f"pyinstaller=={PYINSTALLER_VERSION}"],
                log=REPORT / "cpython31021-pyinstaller.txt",
                cwd=source,
                timeout=900,
            )

            # Build a candidate launcher but do not mutate the live bundle yet.
            dist = WORK / "python31021-launcher-dist"
            build = WORK / "python31021-launcher-build"
            spec = WORK / "python31021-launcher-spec"
            for path in (dist, build, spec, stage):
                remove_path(path)
            run(
                [
                    python_exe, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir", "--console",
                    "--name", "faster-whisper-xxl", "--contents-directory", "_xxl_data",
                    "--distpath", dist, "--workpath", build, "--specpath", spec,
                    TOOLS / "xxl_launcher_comprehensive.py",
                ],
                log=REPORT / "cpython31021-launcher-build.txt",
                cwd=source,
                timeout=1200,
            )
            candidate_launcher = dist / "faster-whisper-xxl"
            shutil.copytree(candidate_launcher / "_xxl_data", stage)

            # Add the patched 3.10.21 standard library and all native extensions.
            excluded = {"site-packages", "test", "ensurepip", "idlelib", "__pycache__"}
            for item in (source / "Lib").iterdir():
                if item.name in excluded:
                    continue
                copy_entry(item, stage / item.name)
            for item in (source / "PCbuild" / "amd64").iterdir():
                if item.is_file() and item.suffix.lower() in {".pyd", ".dll"}:
                    copy_entry(item, stage / item.name)

            # PCbuild stores OpenSSL runtime DLLs in externals rather than amd64.
            copied_ssl: list[str] = []
            for pattern in ("libssl*.dll", "libcrypto*.dll", "libffi*.dll"):
                matches = [
                    item for item in source.rglob(pattern)
                    if item.is_file() and any(marker in str(item).lower() for marker in ("amd64", "x64"))
                ]
                by_name: dict[str, Path] = {}
                for item in matches:
                    by_name[item.name.lower()] = item
                for item in by_name.values():
                    copy_entry(item, stage / item.name)
                    copied_ssl.append(str(item.relative_to(source)))
            if not any(Path(item).name.lower().startswith("libssl") for item in copied_ssl):
                raise RuntimeError("No x64 OpenSSL DLL was found in the CPython source externals")

            shutil.copy2(self.exe, exe_backup)
            overlay_apply(self.contents, stage, backup, manifest, name)
            shutil.copy2(candidate_launcher / "faster-whisper-xxl.exe", self.exe)
            validation = self.full_validation(name, fresh_model=True)
            runtime_json = self.exe_self_test(f"{name}-runtime")
            if not str(runtime_json.get("python", "")).startswith("3.10.21"):
                raise RuntimeError(f"Candidate executable did not report Python 3.10.21: {runtime_json.get('python')!r}")
            overlay_commit(backup, name)
            self.python_runtime_decision = {
                "runtime_info": json.loads(runtime_info.strip().splitlines()[-1]),
                "copied_native_ssl_files": copied_ssl,
                "validation": validation,
                "launcher_runtime": runtime_json,
            }
            self.record(name=name, status_value="accepted", category="python-security-runtime", details=self.python_runtime_decision)
            return True
        except BaseException as exc:
            if backup.exists():
                with contextlib.suppress(Exception):
                    overlay_rollback(self.contents, backup, name)
            if exe_backup.exists():
                shutil.copy2(exe_backup, self.exe)
            self.record(
                name=name,
                status_value="rejected-and-rolled-back",
                category="python-security-runtime",
                details={"error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(limit=40)},
            )
            self.full_validation("rollback-python31021")
            return False
        finally:
            for path in (stage, backup, source, WORK / "python31021-launcher-dist", WORK / "python31021-launcher-build", WORK / "python31021-launcher-spec"):
                remove_path(path)
            if exe_backup.exists():
                exe_backup.unlink()

    def postfix_diarization_regression(self) -> dict[str, Any]:
        status("Running an end-to-end --diarize + --postfix regression test for issue #569.")
        output_dir = REPORT / "inference" / "diarization-postfix-regression"
        remove_path(output_dir)
        output_dir.mkdir(parents=True)
        command = [
            self.exe, self.test_wav, "--model", "tiny.en", "--model_dir", self.model_dir,
            "--device", "cpu", "--compute_type", "int8", "--language", "en",
            "--diarize", "pyannote_v3.1", "--diarize_device", "cpu", "--diarize_threads", "1",
            "--postfix", "--beep_off", "--output_dir", output_dir, "--output_format", "txt",
            "--verbose", "false",
        ]
        run(
            command,
            log=REPORT / "diarization-postfix-regression.txt",
            cwd=self.bundle_root,
            env=exe_environment(self.contents),
            timeout=2400,
        )
        outputs = [path for path in output_dir.rglob("*.txt") if path.stat().st_size > 0]
        if not outputs:
            raise RuntimeError("Diarization/postfix regression did not create a non-empty TXT file")
        if not any("_en" in path.stem for path in outputs):
            raise RuntimeError(f"Postfixed output name was not observed: {[path.name for path in outputs]}")
        return {"outputs": [path.name for path in outputs], "patch_report": "postfix-diarization-patch.json"}

    def modernize(self) -> None:
        baseline = self.full_validation(
            "baseline-gpu-core",
            {
                "torch": "2.11.0",
                "torchvision": "0.26.0",
                "torchaudio": "2.11.0",
                "ctranslate2": "4.8.1",
                "onnxruntime-gpu": "1.23.2",
            },
        )
        self.record(name="gpu-core", status_value="accepted-mandatory", category="gpu-runtime", details=baseline)

        self.test_official_faster_whisper()

        self.try_group(
            "model-download-network-stack",
            [
                "huggingface-hub==0.36.2", "tokenizers==0.23.1", "safetensors==0.8.0",
                "requests==2.34.2", "urllib3==2.7.0", "certifi==2026.7.22",
                "charset-normalizer==3.5.1", "idna==3.19", "filelock==3.32.4",
                "fsspec==2026.7.0", "packaging==26.3", "pyyaml==6.0.3",
                "tqdm==4.70.0", "typing-extensions==4.16.0", "aiohttp==3.14.3",
                "yarl==1.24.5", "multidict==6.7.1", "frozenlist==1.8.0", "attrs==26.1.0",
            ],
            category="network-model-distribution",
            expectations={
                "huggingface-hub": "0.36.2", "tokenizers": "0.23.1",
                "requests": "2.34.2", "urllib3": "2.7.0", "certifi": "2026.7.22",
            },
        )

        self.try_group(
            "numerical-audio-stack",
            [
                "numpy==1.26.4", "scipy==1.15.3", "scikit-learn==1.7.2",
                "pandas==2.3.3", "librosa==0.11.0", "numba==0.67.0",
                "llvmlite==0.49.0", "soundfile==0.14.0", "soxr==1.1.0",
            ],
            category="numerical-audio",
            expectations={
                "numpy": "1.26.4", "scipy": "1.15.3", "scikit-learn": "1.7.2",
                "pandas": "2.3.3", "librosa": "0.11.0", "numba": "0.67.0",
                "llvmlite": "0.49.0", "soundfile": "0.14.0", "soxr": "1.1.0",
            },
        )

        self.try_group(
            "media-ui-utility-stack",
            [
                "numpy==1.26.4", "av==17.1.0", "matplotlib==3.10.9", "pillow==12.3.0",
                "psutil==7.2.2", "rich==15.0.0", "sentencepiece==0.2.2",
                "sympy==1.14.0", "networkx==3.4.2", "jinja2==3.1.6",
                "markupsafe==3.0.3", "regex==2026.7.19", "coloredlogs==15.0.1",
                "flatbuffers==25.12.19", "webrtcvad-wheels==2.0.14", "pyreadline3==3.5.6",
            ],
            category="media-ui-utilities",
            expectations={
                "av": "17.1.0", "matplotlib": "3.10.9", "Pillow": "12.3.0",
                "psutil": "7.2.2", "sympy": "1.14.0",
            },
        )

        self.try_group(
            "crypto-tls-python-packages",
            ["cffi==2.1.1", "cryptography==50.0.0", "pycparser==2.23"],
            category="security-tls",
            expectations={},
        )

        self.try_group(
            "diarization-support-stack",
            [
                "lightning==2.6.5", "pytorch-lightning==2.6.5", "torchmetrics==1.9.0",
                "lightning-utilities==0.15.3", "optuna==4.9.0", "SQLAlchemy==2.0.52",
                "omegaconf==2.3.1", "hydra-core==1.3.5",
            ],
            category="diarization-support",
            expectations={"lightning": "2.6.5", "torchmetrics": "1.9.0", "optuna": "4.9.0", "SQLAlchemy": "2.0.52"},
            no_deps=True,
        )

        self.try_group(
            "packaging-runtime-tools",
            ["setuptools==84.0.0", "wheel==0.48.0"],
            category="packaging-runtime",
            expectations={},
            no_deps=True,
        )

        self.try_group(
            "protobuf-major-candidate",
            ["protobuf==7.36.0", "flatbuffers==25.12.19"],
            category="major-version-candidate",
            expectations={},
            no_deps=True,
        )

        self.try_group(
            "pyannote-v4-major-candidate",
            [
                "pyannote.audio==4.0.7", "pyannote.core==6.0.1", "pyannote.database==6.1.1",
                "pyannote.metrics==4.1", "pyannote.pipeline==4.0.0",
            ],
            category="major-version-candidate",
            expectations={"pyannote.audio": "4.0.7", "pyannote.core": "6.0.1"},
            no_deps=True,
        )

        self.try_ffmpeg()
        self.try_cpython_31021()

        # The dedicated regression uses the final accepted dependency set.
        try:
            details = self.postfix_diarization_regression()
            self.record(name="diarization-postfix-regression", status_value="passed", category="application-bugfix", details=details)
        except BaseException as exc:
            self.record(
                name="diarization-postfix-regression",
                status_value="failed-but-static-bytecode-fix-preserved",
                category="application-bugfix",
                details={"error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(limit=40)},
            )
            # Do not discard the structurally proven path fix merely because a
            # heavyweight diarization model fails in the CI environment.

        self.final_validation = self.full_validation("final-comprehensive", fresh_model=True)
        json_write(REPORT / "final-validation-summary.json", self.final_validation)

    def finalize_metadata(self) -> None:
        status("Writing comprehensive release metadata and checksums.")
        accepted = [item for item in self.decisions if item["status"].startswith("accepted") or item["status"] in {"passed", "not-applied-compatible"}]
        rejected = [item for item in self.decisions if "rejected" in item["status"] or item["status"].startswith("failed")]
        final_versions = self.final_validation.get("versions", {})
        build_info = {
            "format_version": 2,
            "release": "Faster-Whisper-XXL r245.4 comprehensive modernization / RTX 50 / CUDA 12.8",
            "built_at_utc": utc_now(),
            "source_revision": self.git_sha,
            "original_archive": {"url": ORIGINAL_URL, "size_bytes": ORIGINAL_SIZE, "sha256": ORIGINAL_SHA256},
            "builder": {"python": sys.version, "pyinstaller": PYINSTALLER_VERSION},
            "final_versions": final_versions,
            "application_fix": self.patch_report,
            "accepted_changes": [{"name": item["name"], "status": item["status"]} for item in accepted],
            "rejected_or_rolled_back": [{"name": item["name"], "status": item["status"]} for item in rejected],
            "tests": {
                "windows_runner": True,
                "bundled_imports": True,
                "numerical_audio_media_self_tests": True,
                "https_huggingface_download": True,
                "cli_help_version_checkcuda": True,
                "cpu_tiny_en_transcription": True,
                "zip_integrity": "pending",
                "physical_rtx50": False,
            },
        }
        json_write(self.bundle_root / "BUILD-COMPREHENSIVE.json", build_info)
        json_write(self.bundle_root / "DEPENDENCY-DECISIONS.json", self.decisions)
        json_write(self.bundle_root / "FINAL-RUNTIME-VALIDATION.json", self.final_validation)
        shutil.copy2(REPORT / "postfix-diarization-patch.json", self.bundle_root / "POSTFIX-DIARIZATION-FIX.json")

        readme = """Faster-Whisper-XXL r245.4 — comprehensive modernization
================================================================

This build preserves the abandoned XXL application's custom CPython 3.10 code,
but modernizes each independent runtime layer only after Windows compatibility
tests. The exact accepted and rejected candidates are listed in
DEPENDENCY-DECISIONS.json; no failed candidate remains in the package.

Key changes
-----------
- PyTorch 2.11.0 + CUDA 12.8, torchvision 0.26.0, torchaudio 2.11.0
- CTranslate2 4.8.1 with the RTX 50 / INT8 Blackwell fix
- ONNX Runtime GPU 1.23.2 and CUDAExecutionProvider
- Blackwell sm_120 code in the packaged PyTorch build
- PyInstaller 6.22.2 reconstructed launcher with --xxl-runtime-info and
  --xxl-self-test diagnostics
- refreshed dependency groups that passed imports, numerical/audio/media,
  HTTPS, CLI, and complete tiny.en transcription tests
- transactionally tested current Windows FFmpeg/FFprobe and CPython 3.10.21
- fixed r245.4 --diarize + --postfix path/key bug (upstream issue #569)

Use
---
Extract the whole Faster-Whisper-XXL directory. Do not move only the EXE.

Diagnostics:
  faster-whisper-xxl.exe --xxl-runtime-info
  faster-whisper-xxl.exe --xxl-self-test
  faster-whisper-xxl.exe --checkcuda

GPU example:
  faster-whisper-xxl.exe input.wav --device cuda --compute_type auto

Testing boundary
----------------
The full application and transcriptions were tested on Windows Server 2022 x64.
The CI runner had no physical NVIDIA GPU. CUDA DLLs, CUDAExecutionProvider,
CTranslate2, cuDNN and sm_120 were verified, but an actual RTX 50 inference run
must still be performed on the target machine.

Integrity
---------
See SHA256SUMS.txt and BUILD-COMPREHENSIVE.json.
"""
        (self.bundle_root / "README_COMPREHENSIVE.txt").write_text(readme, encoding="utf-8")

        targets = [
            self.exe,
            self.bundle_root / "BUILD-COMPREHENSIVE.json",
            self.bundle_root / "DEPENDENCY-DECISIONS.json",
            self.bundle_root / "FINAL-RUNTIME-VALIDATION.json",
            self.bundle_root / "POSTFIX-DIARIZATION-FIX.json",
            self.bundle_root / "README_COMPREHENSIVE.txt",
        ]
        critical_patterns = [
            "_xxl_data/ctranslate2/ctranslate2.dll",
            "_xxl_data/ctranslate2/_ext.cp310-win_amd64.pyd",
            "_xxl_data/torch/lib/torch_cuda.dll",
            "_xxl_data/torch/lib/cublas64_12.dll",
            "_xxl_data/torch/lib/cublasLt64_12.dll",
            "_xxl_data/torch/lib/cudart64_12.dll",
            "_xxl_data/onnxruntime/capi/onnxruntime_providers_cuda.dll",
            "ffmpeg.exe",
        ]
        for relative in critical_patterns:
            path = self.bundle_root / Path(relative)
            if path.is_file():
                targets.append(path)
        lines = []
        seen: set[Path] = set()
        for path in targets:
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            lines.append(f"{sha256_file(resolved)} *{resolved.relative_to(self.bundle_root).as_posix()}")
        (self.bundle_root / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        for filename in (
            "BUILD-COMPREHENSIVE.json", "DEPENDENCY-DECISIONS.json",
            "FINAL-RUNTIME-VALIDATION.json", "POSTFIX-DIARIZATION-FIX.json",
            "README_COMPREHENSIVE.txt", "SHA256SUMS.txt",
        ):
            shutil.copy2(self.bundle_root / filename, REPORT / filename)

    def package(self) -> Path:
        status("Creating and integrity-testing the complete ZIP64 release.")
        archive = WORK / self.archive_name
        remove_path(archive)
        run(
            ["7z.exe", "a", "-tzip", "-mx=5", "-mmt=on", archive, ".\\Faster-Whisper-XXL"],
            log=REPORT / "7z-create.txt",
            cwd=self.bundle_root.parent,
            timeout=3600,
        )
        run(["7z.exe", "t", archive], log=REPORT / "7z-test.txt", timeout=1800)
        bundle_files = [path for path in self.bundle_root.rglob("*") if path.is_file()]
        info = {
            "filename": archive.name,
            "size_bytes": archive.stat().st_size,
            "sha256": sha256_file(archive),
            "files": len(bundle_files),
            "uncompressed_bytes": sum(path.stat().st_size for path in bundle_files),
        }
        json_write(REPORT / "archive-info.json", info)
        # Mark archive integrity in the report copy (the in-bundle metadata is
        # already immutable inside the tested archive).
        json_write(REPORT / "release-summary.json", {
            "release": "Faster-Whisper-XXL r245.4 comprehensive modernization",
            "archive": info,
            "accepted": [item["name"] for item in self.decisions if item["status"].startswith("accepted")],
            "rejected": [item["name"] for item in self.decisions if "rejected" in item["status"]],
            "physical_rtx50_tested": False,
        })
        return archive

    def upload(self, archive: Path) -> dict[str, Any]:
        status("Uploading the verified ZIP to multiple large-file hosts.")
        info = json.loads((REPORT / "archive-info.json").read_text(encoding="utf-8"))
        hosting: dict[str, Any] = {"archive": info, "hosts": {}, "working_host_count": 0}

        # Buzzheavier anonymous upload.
        try:
            response_path = REPORT / "buzzheavier-response.json"
            run(
                [
                    "curl.exe", "--location", "--fail-with-body", "--retry", "4", "--retry-all-errors",
                    "--connect-timeout", "30", "--upload-file", archive, "--output", response_path,
                    f"https://w.buzzheavier.com/{archive.name}",
                ],
                log=REPORT / "buzzheavier-upload.txt",
                timeout=7200,
            )
            response = json.loads(response_path.read_text(encoding="utf-8-sig"))
            identifier = response.get("data", {}).get("id")
            if not identifier:
                raise RuntimeError(f"Buzzheavier response lacks data.id: {response}")
            url = f"https://buzzheavier.com/{identifier}"
            run(
                ["curl.exe", "--location", "--fail", "--retry", "3", "--max-time", "120", "--output", REPORT / "buzzheavier-page.html", url],
                log=REPORT / "buzzheavier-page-get.txt",
                timeout=180,
            )
            hosting["hosts"]["buzzheavier"] = {"success": True, "url": url, "id": identifier}
            hosting["working_host_count"] += 1
        except BaseException as exc:
            hosting["hosts"]["buzzheavier"] = {"success": False, "error": f"{type(exc).__name__}: {exc}"}

        # Gofile guest upload.
        try:
            response_path = REPORT / "gofile-response.json"
            run(
                [
                    "curl.exe", "--location", "--fail-with-body", "--retry", "4", "--retry-all-errors",
                    "--connect-timeout", "30", "--form", f"file=@{archive}", "--output", response_path,
                    "https://upload.gofile.io/uploadfile",
                ],
                log=REPORT / "gofile-upload.txt",
                timeout=7200,
            )
            response = json.loads(response_path.read_text(encoding="utf-8-sig"))
            if response.get("status") != "ok":
                raise RuntimeError(f"Gofile returned {response}")
            data = response.get("data", {})
            url = data.get("downloadPage") or data.get("downloadPageUrl")
            if not url:
                raise RuntimeError("Gofile response lacks downloadPage")
            run(
                ["curl.exe", "--location", "--fail", "--retry", "3", "--max-time", "120", "--output", REPORT / "gofile-page.html", url],
                log=REPORT / "gofile-page-get.txt",
                timeout=180,
            )
            hosting["hosts"]["gofile"] = {"success": True, "url": url, "guestToken": data.get("guestToken")}
            hosting["working_host_count"] += 1
        except BaseException as exc:
            hosting["hosts"]["gofile"] = {"success": False, "error": f"{type(exc).__name__}: {exc}"}

        # FileDitch is attempted because it was requested, but kept only if an
        # ordinary ranged GET returns ZIP magic rather than a gateway page.
        try:
            response_path = REPORT / "fileditch-response.json"
            endpoint = f"https://new.fileditch.com/upload.php?filename={archive.name}"
            run(
                [
                    "curl.exe", "--location", "--fail-with-body", "--retry", "4", "--retry-all-errors",
                    "--connect-timeout", "30", "--header", "Content-Type: application/octet-stream",
                    "--upload-file", archive, "--output", response_path, endpoint,
                ],
                log=REPORT / "fileditch-upload.txt",
                timeout=7200,
            )
            response = json.loads(response_path.read_text(encoding="utf-8-sig"))
            url = response.get("url")
            if not response.get("success") or not url:
                raise RuntimeError(f"FileDitch returned {response}")
            prefix = REPORT / "fileditch-prefix.bin"
            run(
                [
                    "curl.exe", "--location", "--fail", "--retry", "3", "--range", "0-1048575",
                    "--max-time", "120", "--output", prefix, url,
                ],
                log=REPORT / "fileditch-range-get.txt",
                timeout=180,
            )
            magic = prefix.read_bytes()[:4]
            if magic not in {b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"}:
                raise RuntimeError(f"FileDitch GET did not return ZIP bytes: {magic!r}")
            hosting["hosts"]["fileditch"] = {"success": True, "url": url}
            hosting["working_host_count"] += 1
        except BaseException as exc:
            hosting["hosts"]["fileditch"] = {"success": False, "error": f"{type(exc).__name__}: {exc}"}

        json_write(REPORT / "release-links.json", hosting)
        if hosting["working_host_count"] == 0:
            raise RuntimeError("No large-file host accepted and served the final ZIP")
        return hosting


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive-name", default=DEFAULT_ARCHIVE)
    parser.add_argument("--git-sha", default=os.environ.get("GITHUB_SHA", "unknown"))
    args = parser.parse_args()

    builder = Builder(args.archive_name, args.git_sha)
    try:
        builder.prepare()
        builder.install_gpu_core()
        builder.modernize()
        builder.finalize_metadata()
        archive = builder.package()
        hosting = builder.upload(archive)
        json_write(REPORT / "SUCCESS.json", {
            "success": True,
            "finished_at_utc": utc_now(),
            "archive": json.loads((REPORT / "archive-info.json").read_text(encoding="utf-8")),
            "hosting": hosting,
            "decisions": builder.decisions,
            "physical_rtx50_tested": False,
        })
        status("Comprehensive release build completed successfully.")
        return 0
    except BaseException as exc:
        REPORT.mkdir(parents=True, exist_ok=True)
        json_write(REPORT / "FAILURE.json", {
            "success": False,
            "failed_at_utc": utc_now(),
            "error": f"{type(exc).__name__}: {exc}",
            "traceback": traceback.format_exc(),
            "decisions": getattr(builder, "decisions", []),
        })
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
