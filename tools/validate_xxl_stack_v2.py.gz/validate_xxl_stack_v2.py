#!/usr/bin/env python3
"""Deep, bundle-local compatibility checks for modernized Faster-Whisper-XXL."""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import inspect
import json
import math
import os
import ssl
import sys
import tempfile
import traceback
import wave
from pathlib import Path
from typing import Any, Callable

_DLL_HANDLES: list[Any] = []


def configure(contents: Path) -> list[str]:
    candidates = [
        contents / "torch" / "lib",
        contents / "ctranslate2",
        contents / "onnxruntime" / "capi",
        contents / "av.libs",
        contents / "numpy.libs",
        contents / "scipy.libs",
        contents / "sklearn.libs",
        contents / "pandas.libs",
        contents,
    ]
    existing = [str(path) for path in candidates if path.is_dir()]
    os.environ["PATH"] = os.pathsep.join(existing + [os.environ.get("PATH", "")])
    os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
    os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "0")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    if os.name == "nt" and hasattr(os, "add_dll_directory"):
        for path in existing:
            try:
                _DLL_HANDLES.append(os.add_dll_directory(path))
            except OSError:
                pass
    sys.path.insert(0, str(contents))
    return existing


def version_of(module: Any, distribution: str) -> str:
    value = getattr(module, "__version__", None)
    if value is not None:
        return str(value)
    try:
        return importlib.metadata.version(distribution)
    except Exception:
        return "unknown"


def ensure_inside(module: Any, root: Path, name: str) -> str:
    raw = getattr(module, "__file__", None)
    if not raw:
        raise RuntimeError(f"{name} does not expose __file__")
    path = Path(raw).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise RuntimeError(f"{name} loaded outside bundle: {path}") from exc
    return str(path)


def make_wav(path: Path, seconds: float = 0.35, rate: int = 16000) -> None:
    import struct
    values = [int(8000 * math.sin(2 * math.pi * 440 * i / rate)) for i in range(int(rate * seconds))]
    with wave.open(str(path), "wb") as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(rate)
        stream.writeframes(b"".join(struct.pack("<h", value) for value in values))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("contents_dir", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expect", action="append", default=[])
    parser.add_argument("--network", action="store_true")
    parser.add_argument("--deep", action="store_true")
    args = parser.parse_args()

    contents = args.contents_dir.resolve()
    if not contents.is_dir():
        raise NotADirectoryError(contents)
    expected = dict(item.split("=", 1) for item in args.expect)
    report: dict[str, Any] = {
        "python": sys.version,
        "openssl": ssl.OPENSSL_VERSION,
        "contents": str(contents),
        "dll_search_dirs": configure(contents),
        "versions": {},
        "module_files": {},
        "checks": [],
        "failures": [],
    }
    modules: dict[str, Any] = {}

    def check(name: str, operation: Callable[[], Any]) -> None:
        try:
            report["checks"].append({"name": name, "ok": True, "value": operation()})
        except BaseException as exc:
            report["checks"].append({
                "name": name,
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(limit=20),
            })
            report["failures"].append(name)

    imports = [
        ("torch", "torch"), ("torchvision", "torchvision"), ("torchaudio", "torchaudio"),
        ("ctranslate2", "ctranslate2"), ("onnxruntime-gpu", "onnxruntime"),
        ("faster-whisper", "faster_whisper"), ("tokenizers", "tokenizers"),
        ("huggingface-hub", "huggingface_hub"), ("safetensors", "safetensors"),
        ("requests", "requests"), ("urllib3", "urllib3"), ("certifi", "certifi"),
        ("numpy", "numpy"), ("scipy", "scipy"), ("scikit-learn", "sklearn"),
        ("pandas", "pandas"), ("librosa", "librosa"), ("numba", "numba"),
        ("llvmlite", "llvmlite"), ("soundfile", "soundfile"), ("soxr", "soxr"),
        ("av", "av"), ("psutil", "psutil"), ("Pillow", "PIL"),
        ("matplotlib", "matplotlib"), ("pyannote.audio", "pyannote.audio"),
        ("pyannote.core", "pyannote.core"), ("lightning", "lightning"),
        ("torchmetrics", "torchmetrics"), ("optuna", "optuna"),
        ("SQLAlchemy", "sqlalchemy"),
    ]
    for distribution, import_name in imports:
        def do_import(distribution: str = distribution, import_name: str = import_name) -> dict[str, str]:
            module = importlib.import_module(import_name)
            modules[import_name] = module
            version = version_of(module, distribution)
            location = ensure_inside(module, contents, distribution)
            report["versions"][distribution] = version
            report["module_files"][distribution] = location
            prefix = expected.get(distribution)
            if prefix and not version.startswith(prefix):
                raise RuntimeError(f"{distribution}={version!r}; expected prefix {prefix!r}")
            return {"version": version, "file": location}
        check(f"import:{distribution}", do_import)

    def custom_xxl_api() -> dict[str, Any]:
        fw = modules["faster_whisper"]
        diarization = importlib.import_module("faster_whisper.diarization")
        utils = importlib.import_module("faster_whisper.utils")
        transcribe = importlib.import_module("faster_whisper.transcribe")
        if not hasattr(utils, "download_model_other"):
            raise RuntimeError("custom faster_whisper.utils.download_model_other is missing")
        if not hasattr(transcribe, "BatchedInferencePipeline") and not hasattr(fw, "BatchedInferencePipeline"):
            raise RuntimeError("BatchedInferencePipeline is missing")
        signature = str(inspect.signature(fw.WhisperModel.transcribe))
        return {
            "diarization_module": str(diarization.__file__),
            "transcribe_signature": signature[:6000],
            "download_model_other": True,
            "batched_pipeline": True,
        }
    check("custom-xxl-faster-whisper-api", custom_xxl_api)

    def gpu_runtime() -> dict[str, Any]:
        torch = modules["torch"]
        ct2 = modules["ctranslate2"]
        ort = modules["onnxruntime"]
        flags = str(torch._C._cuda_getArchFlags())  # type: ignore[attr-defined]
        if "sm_120" not in flags.split():
            raise RuntimeError(f"sm_120 missing from {flags!r}")
        providers = ort.get_available_providers()
        if "CUDAExecutionProvider" not in providers:
            raise RuntimeError(f"CUDAExecutionProvider missing: {providers}")
        return {
            "torch_cuda": torch.version.cuda,
            "arch_flags": flags,
            "cudnn": torch.backends.cudnn.version(),
            "torch_cuda_available_on_runner": torch.cuda.is_available(),
            "ctranslate2_cuda_devices_on_runner": ct2.get_cuda_device_count(),
            "ctranslate2_cpu_types": sorted(ct2.get_supported_compute_types("cpu")),
            "onnxruntime_providers": providers,
        }
    check("gpu-runtime", gpu_runtime)

    def native_runtime() -> dict[str, list[str]]:
        names = [
            "cublas64_12.dll", "cublasLt64_12.dll", "cudart64_12.dll",
            "cudnn64_8.dll", "cudnn64_9.dll", "onnxruntime_providers_cuda.dll",
        ]
        found = {name: [path.relative_to(contents).as_posix() for path in contents.rglob(name)] for name in names}
        stale = [path for path in found["cudnn64_8.dll"] if path.lower().startswith("ctranslate2/")]
        if stale:
            raise RuntimeError(f"stale cuDNN 8 next to CTranslate2: {stale}")
        for required in ("cublas64_12.dll", "cublasLt64_12.dll", "cudart64_12.dll", "onnxruntime_providers_cuda.dll"):
            if not found[required]:
                raise RuntimeError(f"missing {required}")
        return found
    check("native-runtime-files", native_runtime)

    if args.deep:
        def numerical_audio() -> dict[str, Any]:
            import numpy as np
            import pandas as pd
            import librosa
            import numba
            import soxr
            from scipy import signal
            from sklearn.preprocessing import StandardScaler

            array = np.arange(12, dtype=np.float32).reshape(3, 4)
            matrix = array @ array.T
            filtered = signal.resample(np.sin(np.linspace(0, 4, 64)), 32)
            scaled = StandardScaler().fit_transform(array)
            frame = pd.DataFrame(array)
            librosa_result = librosa.resample(np.ones(800, dtype=np.float32), orig_sr=16000, target_sr=8000)
            soxr_result = soxr.resample(np.ones(800, dtype=np.float32), 16000, 8000)

            @numba.njit(cache=False)
            def total(values):
                output = 0.0
                for value in values:
                    output += value
                return output

            return {
                "matrix_sum": float(matrix.sum()),
                "scipy_length": len(filtered),
                "scaled_abs_mean": float(abs(scaled.mean())),
                "pandas_shape": list(frame.shape),
                "librosa_length": len(librosa_result),
                "soxr_length": len(soxr_result),
                "numba_total": float(total(np.arange(10, dtype=np.float64))),
            }
        check("numerical-audio-stack", numerical_audio)

        def media_decode() -> dict[str, Any]:
            import av
            import numpy as np
            import soundfile as sf
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "tone.wav"
                make_wav(path)
                data, rate = sf.read(path)
                with av.open(str(path)) as container:
                    frames = list(container.decode(audio=0))
                if not frames or len(data) == 0 or rate != 16000:
                    raise RuntimeError("audio decode returned no samples")
                return {"samples": len(data), "rate": rate, "av_frames": len(frames), "peak": float(np.max(np.abs(data)))}
        check("media-decode", media_decode)

        def plot_render() -> int:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "plot.png"
                figure = plt.figure()
                plt.plot([0, 1], [0, 1])
                figure.savefig(path)
                plt.close(figure)
                if path.stat().st_size < 100:
                    raise RuntimeError("matplotlib render is unexpectedly small")
                return path.stat().st_size
        check("matplotlib-render", plot_render)

    if args.network:
        def https_huggingface() -> dict[str, Any]:
            import certifi
            import requests
            from huggingface_hub import hf_hub_download
            ca_file = Path(certifi.where())
            if not ca_file.is_file() or ca_file.stat().st_size < 100000:
                raise RuntimeError(f"invalid CA bundle: {ca_file}")
            os.environ["SSL_CERT_FILE"] = str(ca_file)
            os.environ["REQUESTS_CA_BUNDLE"] = str(ca_file)
            response = requests.get("https://huggingface.co/api/models/Systran/faster-whisper-tiny.en", timeout=30)
            response.raise_for_status()
            with tempfile.TemporaryDirectory() as directory:
                config = hf_hub_download("Systran/faster-whisper-tiny.en", "config.json", cache_dir=directory)
                size = Path(config).stat().st_size
            return {"status": response.status_code, "ca_file": str(ca_file), "downloaded_config_bytes": size}
        check("https-huggingface", https_huggingface)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"failures": report["failures"], "versions": report["versions"]}, ensure_ascii=False, indent=2))
    return 1 if report["failures"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
